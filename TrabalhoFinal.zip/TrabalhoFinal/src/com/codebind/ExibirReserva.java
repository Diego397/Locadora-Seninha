package com.codebind;

import javax.swing.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class ExibirReserva {
    //NAO PODE MUDAR O NOME DAS VARIAVEIS POR AQUI SENAO BUGA TUDO
    private JPanel ExibirReservaPanel;
    private JLabel ReservaText;
    private JLabel NomeDoClienteText;
    private JLabel CPFText;
    private JLabel ValorDiariaText;
    private JLabel NomeLocadoraText;
    private JLabel CNPJText;
    private JLabel ValorTotalText;
    private JLabel DataRetiradaText;
    private JLabel DataDevolucaoText;
    private JLabel DataEmissaoText;
    private JLabel NumeroComprovanteText;
    private JLabel NomeClienteLabel;
    private JLabel CPFLabel;
    private JLabel ValorDiariaLabel;
    private JLabel NomeLocadoraLabel;
    private JLabel CNPJLabel;
    private JLabel ValorTotalLabel;
    private JLabel DataRetiradaLabel;
    private JLabel DataDevolucaoLabel;
    private JLabel DataEmissaoLabel;
    private JLabel NumeroComprovanteLabel;
    // NAO PODE MUDAR O NOME DAS VARIAVEIS POR AQUI SENAO BUGA TUDO

    public ExibirReserva() {
        ExibirReservaPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                super.componentResized(e);
            }
        });
        ExibirReservaPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentMoved(ComponentEvent e) {
                super.componentMoved(e);
            }
        });
        ExibirReservaPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                super.componentShown(e);
            }
        });
        ExibirReservaPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentHidden(ComponentEvent e) {
                super.componentHidden(e);
            }
        });
        NomeClienteLabel.addComponentListener(new ComponentAdapter() {

        });
    }
}
