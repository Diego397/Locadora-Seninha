package com.codebind;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login {


    //NAO PODE MUDAR O NOME DAS VARIAVEIS POR AQUI SENAO BUGA TUDO
    private JButton EntrarBotao;
    private JPanel LoginPanel;
    private JPasswordField SenhaField;
    private JTextField UsuarioField;
    private JLabel MensagemLabel;
    private JLabel UsuarioLabel;
    private JLabel SenhaLabel;



    public static void main(String[] args){
        JFrame frame01 = new JFrame("Login");
        frame01.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame01.setSize(1366, 768);

        Login login = new Login();

        JPanel panel = new JPanel();

        frame01.setContentPane(new Login().LoginPanel);

        panel.add(login.EntrarBotao);
        panel.add(login.SenhaField);
        panel.add(login.UsuarioField);
        panel.add(login.MensagemLabel);
        panel.add(login.UsuarioLabel);
        panel.add(login.SenhaLabel);

        //frame01.add(panel);

//        frame.pack();
        frame01.setVisible(true);
    }

    public Login() {
        EntrarBotao.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Checa usuario, senha e Vai para a proxima tela


            }
        });
    }
}
