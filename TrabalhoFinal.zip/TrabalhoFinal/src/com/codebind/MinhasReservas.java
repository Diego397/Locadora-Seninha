package com.codebind;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;

public class MinhasReservas {
    private JButton SairBotao;
    private JPanel MinhasReservasPanel;
    private JTable ReversasTabela;

    public MinhasReservas() {
        SairBotao.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Volta para a tela Login
            }
        });
    }
}
